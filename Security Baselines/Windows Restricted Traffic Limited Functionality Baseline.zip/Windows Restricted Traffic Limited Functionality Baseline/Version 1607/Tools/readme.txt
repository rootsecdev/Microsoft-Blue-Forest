LGPO.exe is not included with these baseline packages. 

You can download LGPO.zip from the Microsoft Security Compliance Toolkit locaiton - 

https://www.microsoft.com/en-us/download/details.aspx?id=55319

Once downloaded the zip file, extract it in "Tools" folder.