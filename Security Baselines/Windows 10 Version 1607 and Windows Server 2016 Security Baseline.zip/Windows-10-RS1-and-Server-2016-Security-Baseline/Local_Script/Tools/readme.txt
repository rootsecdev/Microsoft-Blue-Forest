LGPO.exe is not included with this baseline.

You can download it from the Microsoft Security Guidance blog.

https://blogs.technet.microsoft.com/secguide/2016/01/21/lgpo-exe-local-group-policy-object-utility-v1-0/